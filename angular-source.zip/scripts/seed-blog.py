from pathlib import Path
import json,uuid
root=Path(__file__).resolve().parents[1]
articles=[('the-power-of-visual-branding','The Power of Visual Branding','Brand identity','Explore the role of visual identity in how a brand is recognised and experienced.','Visual identity helps people recognise a brand across different settings. The original TraceTimes article explores the relationship between design choices and a brand’s expression.\n\nThis is an archive overview. Read the complete article on the original website for the full discussion.','https://www.tracebrandbuilding.com/the-power-of-visual-branding/'),('creative-hashtags','How Can You Maximize Reach with Creative Hashtags on Social Media?','Social media','An archive overview of Trace’s discussion of hashtags and social content.','The original article discusses how hashtags can support content discovery and brand conversations. It considers different types of tags and the role of context when choosing them.\n\nThis is an archive overview. Platform recommendations can change; read the full original article in its published context.','https://www.tracebrandbuilding.com/how-can-you-maximize-reach-with-creative-hashtags-on-social-media/'),('digital-marketing-vs-demand-generation','Digital Marketing vs Demand Generation Strategy Guide','Marketing strategy','Explore the original TraceTimes discussion of digital marketing and demand generation.','Digital marketing and demand generation address related questions about reaching and engaging an audience. This original TraceTimes guide explores their relationship in a brand and marketing strategy.\n\nThis is an archive overview. Open the original article for the full framework and examples.','https://www.tracebrandbuilding.com/digital-marketing-vs-demand-generation-strategy-guide/')]
posts=[]
for slug,title,cat,excerpt,body,url in articles:
 block=dict(id=str(uuid.uuid4()),type='section',title=title,eyebrow='TRACETIMES / ARCHIVE OVERVIEW',body=body,image='',video='',link=url,button='Read the full original article',theme='light',layout='right',items=[])
 posts.append(dict(id=str(uuid.uuid5(uuid.NAMESPACE_URL,url)),title=title,slug=slug,status='published',blocks=[block],seo=dict(title=title+' | TraceTimes',description=excerpt,canonical=url,image='',noindex=True,contentType='post',author='Bruno Felicidade Jones',excerpt=excerpt,categories=cat,publishedDate='',featuredImage=''),revision=1))
(root/'public/blog-seed.json').write_text(json.dumps(posts,ensure_ascii=False))
q=lambda v:"'"+str(v).replace("'","''")+"'"
sql=['begin;']
for p in posts:
 vals=','.join([q(p['id'])+'::uuid',q(p['title']),q(p['slug']),q('published'),q(json.dumps(p['blocks']))+'::jsonb',q(json.dumps(p['seo']))+'::jsonb','1','now()'])
 sql.append('insert into public.cms_pages(id,title,slug,status,blocks,seo,revision,updated_at) values('+vals+') on conflict do nothing;')
 sql.append('insert into public.cms_public_pages select * from public.cms_pages where id='+q(p['id'])+'::uuid on conflict do nothing;')
sql+=['commit;',"select count(*) as blog_posts from public.cms_public_pages where seo->>'contentType'='post';"]
(root/'supabase/blog-seed.sql').write_text('\n'.join(sql))
