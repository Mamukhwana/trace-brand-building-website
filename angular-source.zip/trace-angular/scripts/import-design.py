from pathlib import Path
from bs4 import BeautifulSoup
import json,uuid,re
root=Path(__file__).resolve().parents[1];source=root.parent/'Trace-Website-HTML'
def text(el):return el.get_text(' ',strip=True) if el else ''
def url(s):
 if not s:return ''
 if s.startswith('https:') or s.startswith('mailto:') or s.startswith('tel:'):return s
 p=s.split('?')[0].split('#')[0].replace('.html','')
 return 'home' if p=='index' else p

def block(typ='section',**fields):return dict(id=str(uuid.uuid4()),type=typ,title='',eyebrow='',body='',image='',video='',link='',button='',theme='light',layout='right',items=[],**fields)
pages=[]
for f in source.glob('*.html'):
 if f.name=='start-here.html':continue
 soup=BeautifulSoup(f.read_text(),'html.parser');main=soup.find('main');blocks=[]
 for section in main.find_all('section',recursive=False):
  classes=section.get('class',[]);typ='section';items=[]
  title=text(section.find(['h1','h2']));eyebrow=text(section.select_one('.eyebrow'));body='\n\n'.join(text(p) for p in section.find_all('p') if 'eyebrow' not in p.get('class',[]) and not p.find_parent('article'))
  image=section.find('img');link=section.select_one('a.button,a.brand-button,a.text-link');video=section.find('video');theme='dark' if any(x in classes for x in ['home-hero','dark-section','closing-cta']) else 'soft' if 'soft' in classes or 'services-section' in classes else 'light'
  if 'home-hero' in classes:typ='hero'
  elif section.select('.project-grid'):
   typ='projects';title=title or 'Selected work'
   for el in section.select('article.project'):
    img=el.find('img');a=el.find('a');items.append(dict(title=text(el.find('h3')),body='',image=img.get('src','') if img else '',link=url(a.get('href','')) if a else '',label=text(el.select_one('.project-meta p'))))
  elif section.select('.people-grid'):
   typ='team';title='The people behind Trace.'
   for el in section.select('article.person'):
    img=el.find('img');items.append(dict(title=text(el.find('h2')),body='',image=img.get('src','') if img else '',link='',label=text(el.select_one('.eyebrow'))))
  elif section.find('details'):
   typ='faq';items=[dict(title=text(d.find('summary')),body=text(d.find('p')),image='',link='',label='') for d in section.find_all('details')];body=''
  elif 'closing-cta' in classes:typ='cta'
  elif section.select('.steps>div,.editorial-card,.service-rows>a,.original-services article'):
   typ='columns'
   for el in section.select('.steps>div,.editorial-card,.service-rows>a,.original-services article'):
    img=el.find('img');a=el if el.name=='a' else el.find('a');items.append(dict(title=text(el.find(['h2','h3'])),body=text(el.find('p',class_=lambda c:c!='eyebrow')),image=img.get('src','') if img else '',link=url(a.get('href','')) if a else '',label='Explore'))
   body=''
  else:
   for li in section.select('ul.plain-list li'):items.append(dict(title=text(li),body='',image='',link='',label=''))
  b=block();b.update(type=typ,title=title,eyebrow=eyebrow,body=body,image=image.get('src','') if image and typ not in ['projects','team','columns'] else '',video=video.find('source').get('src','') if video and video.find('source') else '',link=url(link.get('href','')) if link else '',button=text(link),theme=theme,items=items)
  if typ=='hero':b['body']=text(section.select_one('.intro'))
  blocks.append(b)
 slug='home' if f.stem=='index' else f.stem
 desc=soup.find('meta',attrs={'name':'description'})
 pages.append(dict(id=str(uuid.uuid5(uuid.NAMESPACE_URL,'https://tracebrandbuilding.com/'+slug)),title=soup.title.text.split(' | ')[0],slug=slug,status='draft',blocks=blocks,seo=dict(title=soup.title.text,description=desc.get('content','') if desc else '',canonical='',image='',noindex=True),revision=0,updated_at='2026-10-28T00:00:00Z'))
(root/'public/seed.json').write_text(json.dumps(pages,ensure_ascii=False))
assets=[]
for f in (root/'public/assets').iterdir():
 if f.suffix.lower() in ['.webp','.png','.jpg','.jpeg','.mp4','.gif']:assets.append(dict(name=f.stem.replace('-',' '),url='assets/'+f.name))
(root/'public/media.json').write_text(json.dumps(assets))
print('Imported',len(pages),'pages;',len(assets),'media assets')
