import {readFile,writeFile,mkdir,copyFile,readdir} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));const out=join(root,'dist/trace/browser');
for(const name of ['index.html',...(await readdir(out)).filter(n=>n.endsWith('.css'))]){const f=join(out,name);let s=await readFile(f,'utf8');s=s.replace(/(?:\.\/)?media\/open-sans-semibold-[A-Z0-9]+\.woff2/g,'./assets/open-sans-semibold.woff2').replace(/(?:\.\/)?media\/open-sans-[A-Z0-9]+\.woff2/g,'./assets/open-sans.woff2');await writeFile(f,s);}
await writeFile(join(out,'.nojekyll'),'');
await copyFile(join(root,'README.md'),join(out,'README.md'));
console.log('GitHub Pages package prepared.');
// Preserve URLs from the earlier static prototype.
const pages=JSON.parse(await readFile(join(out,'seed.json'),'utf8'));
for(const page of pages){if(page.slug==='home')continue;if(!/^[a-z0-9-]+$/.test(page.slug))throw new Error('Invalid seed slug');const destination='./#/'+page.slug;await writeFile(join(out,page.slug+'.html'),'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="robots" content="noindex,nofollow"><meta http-equiv="refresh" content="0;url='+destination+'"><title>Trace Brand Building</title></head><body><a href="'+destination+'">Open this page</a></body></html>');}
