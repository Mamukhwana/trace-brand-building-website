import {readFile,writeFile,mkdir,copyFile,readdir} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));const out=join(root,'dist/trace/browser');
for(const name of ['index.html',...(await readdir(out)).filter(n=>n.endsWith('.css'))]){const f=join(out,name);let s=await readFile(f,'utf8');s=s.replace(/(?:\.\/)?media\/open-sans-semibold-[A-Z0-9]+\.woff2/g,'./assets/open-sans-semibold.woff2').replace(/(?:\.\/)?media\/open-sans-[A-Z0-9]+\.woff2/g,'./assets/open-sans.woff2');await writeFile(f,s);}
await writeFile(join(out,'.nojekyll'),'');
await copyFile(join(root,'README.md'),join(out,'README.md'));
console.log('GitHub Pages package prepared.');
