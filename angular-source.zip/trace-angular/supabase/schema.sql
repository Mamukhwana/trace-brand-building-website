begin;
create table if not exists public.cms_members(user_id uuid primary key references auth.users(id) on delete cascade,created_at timestamptz not null default now());
alter table public.cms_members enable row level security;
create or replace function public.cms_is_admin() returns boolean language sql stable security definer set search_path='' as $$ select exists(select 1 from public.cms_members where user_id=auth.uid()) $$;
revoke all on function public.cms_is_admin() from public;grant execute on function public.cms_is_admin() to authenticated;
drop policy if exists member_self_read on public.cms_members;
create policy member_self_read on public.cms_members for select to authenticated using(user_id=(select auth.uid()));
create table if not exists public.cms_pages(id uuid primary key,title text not null,slug text not null unique check(slug~'^[a-z0-9]+(-[a-z0-9]+)*$'),status text not null default 'draft' check(status in('draft','published')),blocks jsonb not null default '[]',seo jsonb not null default '{}',revision integer not null default 1,updated_at timestamptz not null default now());
create table if not exists public.cms_public_pages(like public.cms_pages including all);
create table if not exists public.cms_revisions(id bigint generated always as identity primary key,page_id uuid not null references public.cms_pages(id) on delete cascade,revision integer not null,document jsonb not null,created_at timestamptz not null default now(),created_by uuid references auth.users(id));
create table if not exists public.cms_public_settings(id integer primary key check(id=1),value jsonb not null);
alter table public.cms_pages enable row level security;alter table public.cms_public_pages enable row level security;alter table public.cms_revisions enable row level security;alter table public.cms_public_settings enable row level security;
drop policy if exists admin_read_pages on public.cms_pages;create policy admin_read_pages on public.cms_pages for select to authenticated using((select public.cms_is_admin()));
drop policy if exists admin_read_revisions on public.cms_revisions;create policy admin_read_revisions on public.cms_revisions for select to authenticated using((select public.cms_is_admin()));
drop policy if exists visitor_read_published on public.cms_public_pages;create policy visitor_read_published on public.cms_public_pages for select to anon,authenticated using(status='published');
drop policy if exists visitor_read_settings on public.cms_public_settings;create policy visitor_read_settings on public.cms_public_settings for select to anon,authenticated using(true);
revoke all on public.cms_members,public.cms_pages,public.cms_public_pages,public.cms_revisions,public.cms_public_settings from anon,authenticated;
grant select on public.cms_members,public.cms_pages,public.cms_revisions to authenticated;
grant select on public.cms_public_pages,public.cms_public_settings to anon,authenticated;
create or replace function public.cms_save_page(document jsonb,expected_revision integer) returns jsonb language plpgsql security definer set search_path='' as $$
declare existing public.cms_pages; result public.cms_pages; target uuid; next_revision integer;
begin
 if not public.cms_is_admin() then raise exception 'Administrator access required' using errcode='42501';end if;
 if jsonb_typeof(document)<>'object' or octet_length(document::text)>1048576 then raise exception 'Invalid page document';end if;
 if coalesce(length(trim(document->>'title')),0)=0 or length(document->>'title')>200 then raise exception 'A page title is required (maximum 200 characters)';end if;
 if coalesce(document->>'slug','')!~'^[a-z0-9]+(-[a-z0-9]+)*$' then raise exception 'Invalid page slug';end if;
 if jsonb_typeof(document->'blocks')<>'array' or jsonb_array_length(document->'blocks')>100 then raise exception 'Invalid sections';end if;
 if jsonb_typeof(document->'seo')<>'object' then raise exception 'Invalid SEO settings';end if;
 target=(document->>'id')::uuid;select * into existing from public.cms_pages where id=target for update;
 if found then
  if existing.revision<>expected_revision then raise exception 'This page changed in another session. Reload it before saving.' using errcode='40001';end if;
  next_revision=existing.revision+1;
 else
  if expected_revision<>0 then raise exception 'The original page was not found';end if;next_revision=1;
 end if;
 insert into public.cms_pages as p(id,title,slug,status,blocks,seo,revision,updated_at)
 values(target,trim(document->>'title'),document->>'slug',coalesce(existing.status,'draft'),document->'blocks',document->'seo',next_revision,now())
 on conflict(id) do update set title=excluded.title,slug=excluded.slug,blocks=excluded.blocks,seo=excluded.seo,revision=excluded.revision,updated_at=excluded.updated_at returning * into result;
 insert into public.cms_revisions(page_id,revision,document,created_by) values(target,next_revision,to_jsonb(result),auth.uid());return to_jsonb(result);
end $$;
create or replace function public.cms_publish_page(page_id uuid,expected_revision integer) returns void language plpgsql security definer set search_path='' as $$
declare p public.cms_pages;
begin
 if not public.cms_is_admin() then raise exception 'Administrator access required' using errcode='42501';end if;
 select * into p from public.cms_pages where id=page_id for update;
 if not found then raise exception 'Page not found';end if;
 if p.revision<>expected_revision then raise exception 'The draft has changed. Reload before publishing.' using errcode='40001';end if;
 update public.cms_pages set status='published' where id=page_id;
 insert into public.cms_public_pages(id,title,slug,status,blocks,seo,revision,updated_at) values(p.id,p.title,p.slug,'published',p.blocks,p.seo,p.revision,now())
 on conflict(id) do update set title=excluded.title,slug=excluded.slug,status=excluded.status,blocks=excluded.blocks,seo=excluded.seo,revision=excluded.revision,updated_at=excluded.updated_at;
end $$;
create or replace function public.cms_unpublish_page(page_id uuid) returns void language plpgsql security definer set search_path='' as $$ begin
 if not public.cms_is_admin() then raise exception 'Administrator access required' using errcode='42501';end if;
 delete from public.cms_public_pages where id=page_id;update public.cms_pages set status='draft' where id=page_id;
end $$;
create or replace function public.cms_save_settings(settings jsonb) returns void language plpgsql security definer set search_path='' as $$ begin
 if not public.cms_is_admin() then raise exception 'Administrator access required' using errcode='42501';end if;
 if jsonb_typeof(settings)<>'object' or octet_length(settings::text)>16000 then raise exception 'Invalid settings';end if;
 insert into public.cms_public_settings(id,value) values(1,settings) on conflict(id) do update set value=excluded.value;
end $$;
revoke all on function public.cms_save_page(jsonb,integer),public.cms_publish_page(uuid,integer),public.cms_unpublish_page(uuid),public.cms_save_settings(jsonb) from public;
grant execute on function public.cms_save_page(jsonb,integer),public.cms_publish_page(uuid,integer),public.cms_unpublish_page(uuid),public.cms_save_settings(jsonb) to authenticated;
insert into public.cms_public_settings values(1,'{"name":"Trace Brand Building","description":"Brand strategy, identity and campaigns.","siteUrl":"https://mamukhwana.github.io/trace-brand-building-website/","email":"tracey@tracebrandbuilding.com","phone":"+1 303 619 7577","noindex":true}') on conflict do nothing;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('trace-media','trace-media',true,26214400,array['image/jpeg','image/png','image/webp','image/gif','video/mp4']) on conflict(id) do nothing;
drop policy if exists trace_media_read on storage.objects;create policy trace_media_read on storage.objects for select to anon,authenticated using(bucket_id='trace-media');
drop policy if exists trace_media_insert on storage.objects;create policy trace_media_insert on storage.objects for insert to authenticated with check(bucket_id='trace-media' and (select public.cms_is_admin()));
commit;
