import { bootstrapApplication } from '@angular/platform-browser';
import { provideRouter,withHashLocation } from '@angular/router';
import { provideZonelessChangeDetection } from '@angular/core';
import { AppComponent } from './app/app';
import { routes } from './app/routes';
bootstrapApplication(AppComponent,{providers:[provideZonelessChangeDetection(),provideRouter(routes,withHashLocation())]}).catch(console.error);
