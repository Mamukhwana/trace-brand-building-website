import { bootstrapApplication } from '@angular/platform-browser';
import { provideRouter,withHashLocation } from '@angular/router';
import { provideZonelessChangeDetection,provideAppInitializer,inject } from '@angular/core';
import { AppComponent } from './app/app';
import { routes } from './app/routes';
import { Store } from './app/store';
bootstrapApplication(AppComponent,{providers:[provideZonelessChangeDetection(),provideAppInitializer(()=>inject(Store).ready),provideRouter(routes,withHashLocation())]}).catch(console.error);
