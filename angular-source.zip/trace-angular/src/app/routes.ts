import { inject } from '@angular/core';
import { CanActivateFn,Routes,Router } from '@angular/router';
import { Store } from './store';
const adminGuard:CanActivateFn=async()=>{const s=inject(Store),r=inject(Router);await s.ready;await s.checkAdmin();return s.admin()||s.preview()?true:r.createUrlTree(['/admin/login']);};
export const routes:Routes=[{path:'admin/reset',loadComponent:()=>import('./reset').then(m=>m.ResetComponent)},{path:'admin/login',loadComponent:()=>import('./login').then(m=>m.LoginComponent)},{path:'admin',canActivate:[adminGuard],loadComponent:()=>import('./admin').then(m=>m.AdminComponent)},{path:'',loadComponent:()=>import('./public').then(m=>m.PublicComponent)},{path:':slug',loadComponent:()=>import('./public').then(m=>m.PublicComponent)},{path:'**',redirectTo:''}];
