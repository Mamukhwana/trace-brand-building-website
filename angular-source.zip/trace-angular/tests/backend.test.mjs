import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
const c=JSON.parse(await readFile(new URL('../public/config.json',import.meta.url),'utf8'));
const headers={apikey:c.supabaseKey,'Content-Type':'application/json'};
const call=(path,options={})=>fetch(c.supabaseUrl+'/rest/v1/'+path,{headers,...options});
test('anonymous visitors can read the published site',async()=>{const r=await call('cms_public_pages?select=id,slug,blocks');assert.equal(r.status,200);const pages=await r.json();assert.equal(pages.length,20);assert.ok(pages.find(p=>p.slug==='home'));});
test('anonymous visitors cannot read drafts or revisions',async()=>{for(const table of ['cms_pages','cms_revisions']){const r=await call(table+'?select=*');assert.ok([401,403].includes(r.status),table+' returned '+r.status);}});
test('anonymous visitors cannot save or publish pages',async()=>{for(const [rpc,body] of [['cms_save_page',{document:{},expected_revision:0}],['cms_publish_page',{page_id:'00000000-0000-0000-0000-000000000001',expected_revision:1}]]){const r=await call('rpc/'+rpc,{method:'POST',body:JSON.stringify(body)});assert.ok([401,403].includes(r.status),rpc+' returned '+r.status);}});
