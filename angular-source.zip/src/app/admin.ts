import { Component,inject,signal,OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router,RouterLink,ActivatedRoute } from '@angular/router';
import { DragDropModule,CdkDragDrop,moveItemInArray } from '@angular/cdk/drag-drop';
import { Store } from './store';
import { Page,Block,BlockType,Item,SiteSettings,newBlock,safeMedia,sliderDefaults } from './models';
import { BlockComponent } from './blocks';
import { SliderControlsComponent } from './slider-controls';
@Component({selector:'trace-admin',standalone:true,imports:[FormsModule,RouterLink,DragDropModule,BlockComponent,SliderControlsComponent],templateUrl:'./admin.html'})
export class AdminComponent implements OnInit {
 store=inject(Store);router=inject(Router);view=signal('overview');settingsTab=signal('general');sliderIndex=signal(0);route=inject(ActivatedRoute);page=signal<Page|null>(null);selected=signal(0);tab=signal('content');busy=signal(false);notice=signal('');error=signal('');search=signal('');device=signal('desktop');dirty=signal(false);history=signal<any[]>([]);mediaTarget=signal<'image'|'video'>('image');settings:SiteSettings={...this.store.settings()};before:Page[]=[];after:Page[]=[];media=safeMedia;
 publishedPredicate=(p:Page)=>p.status==='published';
 addType(type:string){this.add(type as BlockType);}
 types:BlockType[]=['hero','section','columns','image','video','projects','team','faq','cta','slider'];
 assets=signal<{name:string;url:string}[]>([]);
 async ngOnInit(){const qp=this.route.snapshot.queryParamMap;const requested=qp.get('view');if(requested&&['pages','blogs','settings'].includes(requested))this.view.set(requested);if(qp.get('tab')==='integrations')this.settingsTab.set('integrations');await this.store.ready;try{await this.store.loadPages();await this.store.publicSettings();this.settings={...this.store.settings()};this.assets.set([...(await this.store.listMedia()),...(await(await fetch('media.json')).json())]);}catch(e){this.fail(e);}}
 selectBlock(event:MouseEvent,index:number){if((event.target as Element).closest('a'))event.preventDefault();this.selected.set(index);}
 isPost(p:Page){return p.seo.contentType==='post';}
 filtered(){const q=this.search().toLowerCase();return this.store.pages().filter(p=>this.isPost(p)===(this.view()==='blogs')&&(p.title+' '+p.slug).toLowerCase().includes(q));}
 active(){return this.page()?.blocks[this.selected()];}
 snapshot(){if(this.page()){this.before.push(structuredClone(this.page()!));this.before=this.before.slice(-40);this.after=[];}this.dirty.set(true);}
 change(){this.dirty.set(true);this.page.update(p=>p?{...p,blocks:p.blocks.map(b=>({...b}))}:p);}
 async navigate(view:string){if(this.dirty()&&!confirm('Leave the editor without saving your changes?'))return;if(view==='analytics'){await this.router.navigate(['/admin/analytics']);return;}this.view.set(view);this.page.set(null);this.dirty.set(false);this.notice.set('');this.error.set('');}
 edit(p:Page){if(this.dirty()&&!confirm('Discard unsaved changes?'))return;this.page.set(structuredClone(p));this.selected.set(0);this.view.set('editor');this.dirty.set(false);this.before=[];this.after=[];this.notice.set('');this.error.set('');}
 create(post=false){if(this.dirty()&&!confirm('Discard unsaved changes?'))return;this.edit({id:crypto.randomUUID(),title:post?'Untitled article':'Untitled page',slug:(post?'new-article-':'new-page-')+Date.now().toString().slice(-5),status:'draft',blocks:[newBlock(post?'section':'hero')],seo:{title:'',description:'',canonical:'',image:'',noindex:true,contentType:post?'post':'page',author:post?'Trace Brand Building':'',publishedDate:post?new Date().toISOString().slice(0,10):'',excerpt:'',categories:'',featuredImage:''},revision:0,updated_at:new Date().toISOString()});this.dirty.set(true);}
 add(type:BlockType){this.snapshot();this.page.update(p=>{if(!p)return p;const b=newBlock(type);if(type==='slider'){b.slider={...sliderDefaults};b.items=[{title:'Your next chapter.',body:'Add your slide message.',image:'assets/binoculars.png',link:'contact',label:'Let’s talk',x:10,y:50,imageX:65,imageY:50,scale:.65,fontSize:42,color:'#ffffff',background:'#000000'}];this.sliderIndex.set(0);}if(['columns','faq'].includes(type))b.items=[{title:'First item',body:'Add a description.',image:'',link:'',label:''}];return {...p,blocks:[...p.blocks,b]};});this.selected.set(this.page()!.blocks.length-1);}
 drop(e:CdkDragDrop<Block[]>){this.snapshot();const id=this.active()?.id;this.page.update(p=>{if(!p)return p;const b=[...p.blocks];moveItemInArray(b,e.previousIndex,e.currentIndex);return {...p,blocks:b};});this.selected.set(this.page()!.blocks.findIndex(b=>b.id===id));}
 move(index:number,delta:number){const next=index+delta;if(next<0||next>=this.page()!.blocks.length)return;this.drop({previousIndex:index,currentIndex:next} as CdkDragDrop<Block[]>);}
 duplicate(index:number){this.snapshot();this.page.update(p=>{if(!p)return p;const blocks=[...p.blocks];blocks.splice(index+1,0,{...structuredClone(blocks[index]),id:crypto.randomUUID()});return {...p,blocks};});this.selected.set(index+1);}
 remove(index:number){if(!confirm('Remove this section? You can undo before saving.'))return;this.snapshot();this.page.update(p=>p?{...p,blocks:p.blocks.filter((_,i)=>i!==index)}:p);this.selected.set(Math.max(0,index-1));}
 undo(){if(!this.before.length)return;this.after.push(structuredClone(this.page()!));this.page.set(this.before.pop()!);this.selected.set(0);this.dirty.set(true);}
 redo(){if(!this.after.length)return;this.before.push(structuredClone(this.page()!));this.page.set(this.after.pop()!);this.selected.set(0);this.dirty.set(true);}
 addItem(){this.snapshot();this.active()!.items.push({title:'New item',body:'',image:'',link:'',label:''});this.change();}
 removeItem(index:number){this.snapshot();this.active()!.items.splice(index,1);this.change();}
 async save(publish=false){if(!this.page())return;this.busy.set(true);this.error.set('');try{const result=publish?await this.store.publish(this.page()!):await this.store.save(this.page()!);this.page.set(structuredClone(result));this.dirty.set(false);this.notice.set(publish?'Published. Visitors will see this version.':this.store.preview()?'Saved in this browser only.':'Draft saved. The published version is unchanged.');}catch(e){this.fail(e);}finally{this.busy.set(false);}}
 async unpublish(){if(!confirm('Remove this page from the public website? The draft will remain.'))return;await this.task(async()=>{await this.store.unpublish(this.page()!.id);this.page.update(p=>p?{...p,status:'draft'}:p);this.notice.set('Page unpublished.');});}
 async showHistory(){await this.task(async()=>{this.history.set(await this.store.revisions(this.page()!.id));this.tab.set('history');});}
 restore(document:Page){if(!confirm('Restore this revision as an unsaved draft?'))return;this.snapshot();const current=this.page()!;this.page.set({...structuredClone(document),revision:current.revision,status:current.status});this.selected.set(0);this.tab.set('content');}
 chooseAsset(url:string){if(this.view()==='editor'&&this.active()){this.snapshot();const b=this.active()!;if(b.type==='slider'){const slide=b.items[this.sliderIndex()];if(slide)slide[this.mediaTarget()]=url;}else b[this.mediaTarget()]=url;this.change();this.tab.set('content');}}
 async upload(event:Event){const input=event.target as HTMLInputElement;const file=input.files?.[0];if(!file)return;await this.task(async()=>{const url=await this.store.upload(file);this.assets.update(xs=>[{name:file.name,url},...xs]);this.notice.set('Media uploaded. Select it to use it in the active section.');});input.value='';}
 async importPages(){await this.task(async()=>{await this.store.importSeed();this.notice.set('Trace pages imported as drafts. Review and publish each page when ready.');});}
 async saveSettings(){await this.task(async()=>{await this.store.saveSettings(this.settings);this.notice.set(this.store.preview()?'Settings preview updated.':'Website settings saved.');});}
 async signOut(){if(this.dirty()&&!confirm('Sign out and discard unsaved changes?'))return;await this.store.logout();await this.router.navigate(['/admin/login']);}
 fail(e:unknown){this.error.set(this.store.message(e));}
 async task(fn:()=>Promise<void>){this.busy.set(true);this.error.set('');this.notice.set('');try{await fn();}catch(e){this.fail(e);}finally{this.busy.set(false);}}
 exportPage(){const blob=new Blob([JSON.stringify(this.page(),null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=this.page()!.slug+'.json';a.click();URL.revokeObjectURL(url);}
}
